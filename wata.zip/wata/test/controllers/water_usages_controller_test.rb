require 'test_helper'

class WaterUsagesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
