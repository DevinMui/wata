class WaterUsage < ActiveRecord::Base
end
