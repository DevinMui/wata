FAYE_TOKEN = "anything"
